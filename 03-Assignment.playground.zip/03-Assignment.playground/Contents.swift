// 1️⃣ Create a program that uses a for loop to print out all the numbers from 1 to 10.
func firstProgram() {
    for i in 1...10 {
        print(i)
    }
}
firstProgram()


// 2️⃣ Write a program that uses a while loop to print out all the even numbers from 2 to 20.

func secondProgram() {
    var evenNum = 0
    while(evenNum < 20) {
        evenNum += 1
        if (evenNum % 2 == 0) {
            print(evenNum)
        }
    }
}
secondProgram()

// 3️⃣ Write a function that takes an array of strings as an argument and returns a new array that contains only the strings that have more than 4 characters.

func thirdProgram(stringsArgument:[String]) -> [String] {
    var strings : [String] = []
    for element in stringsArgument {
        if element.count > 4 {
            strings.append(element)
        }
    }
    print(strings)
    return strings
}
thirdProgram(stringsArgument: ["","Ran","Ranee","Raneem"])

// 4️⃣ Write a program that uses a switch statement to determine whether a given number is positive, negative, or zero.

func forthProgram(num: Int) {
    switch num {
    case 0:
        print("Zero")
    case 0...:
        print("Positive")
    default:
        print("Negative")
    }
}
forthProgram(num: 0)
forthProgram(num: 7)
forthProgram(num: -7)

// 5️⃣ Write a program that uses an if statement to check if a given number is even or odd. If the number is even, print "even"; if it's odd, print "odd".
func fifthProgram (num: Int) {
    if num % 2 == 0 {
        print("It's an even")
    } else {
        print("It's an odd")
    }
}
fifthProgram(num: 0)
fifthProgram(num: 2)
fifthProgram(num: 3)

// 6️⃣ Write a program that uses a for-in loop to iterate over a dictionary and print out all the key-value pairs.
func sixthProgram(dictionary : [String : String]) {
    for element in dictionary {
        print("Key: \(element.key), Value: \(element.value)")
    }
}
sixthProgram(dictionary: ["Green": "Garden", "Yellow": "Sun"])

// 7️⃣ Create a program that uses a for-in loop to iterate over a range of numbers and print out all the numbers that are divisible by 3.
func seventhProgram(numArray: [Int]) {
    for element in numArray {
        if (element % 3 == 0) {
            print(element)
        }
    }
}
seventhProgram(numArray: [0,1,2,6,29,30])
