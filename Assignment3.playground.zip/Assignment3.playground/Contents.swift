print("Q1:")
for i in 1...10 {
    print(i)
}



print("Q2:")
var number = 2

while number <= 20 {
    if number % 2 == 0 {
        print(number)
    }
    number+=1
}



print("Q3:")

func ArrayS (arraystring:[String])->[String]{

    var newArray:[String]=[]
    for i in arraystring{
        if   i.count > 4 {
            newArray.append(i)
        }
        }
   return newArray
}


print(ArrayS(arraystring: ["A77777","B222" , "Nada","Caaa555"]))




print("Q4:")
var number4 = 99
switch number4 {
case 0:
    print("Zero")
case let x where x > 0:
    print("postive")
default:
    print("Negtive")
}


print("Q5:")
var number2 = 25
if number2 % 2 == 0 {
    print("It's even")
}else{
    print("It's odd")
}

print("Q6")
var studentGrades :[String : Int] = ["Nada" : 100 , "Rand" : 90 , "Abeer": 80]
for i in studentGrades {
    print(i)
}


print("Q7")
for number in 1...10 {
    if number % 3 == 0 {
        print(number)}
}
