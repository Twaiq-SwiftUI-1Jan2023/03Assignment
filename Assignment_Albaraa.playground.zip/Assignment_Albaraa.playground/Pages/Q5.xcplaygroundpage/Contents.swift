//: [Previous](@previous)

import Foundation

//Write a program that uses an if statement to check if a given number is even or odd. If the number is even, print "even"; if it's odd, print "odd".
func oddoreven(num : Int)  {
    if(num % 2 == 0){
        print("\(num)  is even");
    }
    else {
        print("\(num)  is odd");
    }
}
    oddoreven(num: 8)
