//: [Previous](@previous)

import Foundation

//Write a function that takes an array of strings as an argument and returns a new array that contains only the strings that have more than 4 characters.
func foo1(_ arr : [String] ) -> [String]{
    var a = [String]()
    
    
    for value in arr {
        if value.count > 4 {
            a.append(value)
        }
    }
return a
}
foo1 ( ["albaraa" ,"sai","malek","khaled","saad"])


// MARK: -
