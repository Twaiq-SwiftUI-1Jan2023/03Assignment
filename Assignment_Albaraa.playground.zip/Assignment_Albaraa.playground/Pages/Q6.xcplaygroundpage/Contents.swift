//: [Previous](@previous)

import Foundation

//Write a program that uses a for-in loop to iterate over a dictionary and print out all the key-value pairs.
let dic = ["SA":"Saudi Arabia"
          ,"AE":"United Arab Emirates"
           ,"ZA":"South Africa"
]
for i in dic {
    print(i)
}
