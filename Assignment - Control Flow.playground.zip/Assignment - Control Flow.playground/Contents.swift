import UIKit
// Q1
for i in 1...10 {
    print(i)
}

// Q2
var num = 0
while num <= 20 {
    print(num)
    num += 2
}

// Q3
var character = ["Sarraa", "Nada", "Hi", "World"]
let result = character.filter { charec in charec.count > 4 }
print(result)
