import UIKit
//Q1
for i in 1...10 {
    print (i)
}
//Q2
var x = 2
while x <= 20 {
    if x % 2 == 0 {
        print (x)
    }
    x+=1
}
//Q3
var Array = ["HATOUN" , "HATEEF" , "SARA" , "MAHA"]
var Ar2 = String ()
func Ar2 (Array: Array <String>)-> Array <String>{
    for M in Array{
        if M.count > 4{
            Ar2.append(M)
        }
        return Ar2
    }
    print(Ar2(Array: Array))
    
    
    //Q4
    
    let number :Int = 2
    let num = true
    switch num {
    case number > 0 :
        print ("Positive")
    case number == 0 :
        print ("Zero")
    case number < 0 :
        print ("Negative")
    default:
        print("null")
    }
    
    //Q5
    var y = 22
    if y % 2 == 0{
        print ("even")
    }
    else{
        print("odd")
    }
    
    //Q6
    var dictionary :[String :String] = ["lastname" :"hatoun" ,"fristname" : "alsahli"]
    for v in dictionary{
        print (v)
    }
    
    
    // Q7
    for H in 0...30 {
        if H % 3 == 0 {
            print (H)
        }
    }
}
